# Synapse Analytics Workspace `[Microsoft.Synapse/workspaces]`

This module deploys a Synapse Analytics Workspace.

Copy synapse.main.bicep file, paste it in the respective resource group folder under the subscription and complete the pull request to main branch to run the deployment.


## Resource Types

| Resource Type | API Version |
| :-- | :-- |
| `Microsoft.Authorization/locks` | 2017-04-01 |
| `Microsoft.Authorization/roleAssignments` | 2021-04-01-preview |
| `Microsoft.Synapse/workspaces` | 2021-06-01 |
| `Microsoft.Storage/storageAccounts` | 2021-01-01|
| `Microsoft.Synapse/workspaces/sqlPools` | 2021-03-01 |
| `Microsoft.Storage/storageAccounts/blobServices/containers` | 2021-01-01 |

## Parameters

| Parameter Name | Type | Default Value | Possible Values | Description |
| :-- | :-- | :-- | :-- | :-- |
| `resourcePrefix` | string | `syn` |  | Resource prefix for the resource naming |
| `partner` | string | `hub` |  | Name of the partner subscription the resource is being deployed to. Eg: hub, pimco, etc |
| `environment` | string | `dev` | `dev`, `sit`, `uat`, `stg`, `shr-nprd`, `shr-prd`, `demo`, `prd-dr`, `shr-prd-dr`, `sbx` | Environment. |
| `application` | string | ` ` |  | Optional. Application name to be added in the name of the resource. |
| `sequence` | string |  |  | Optional. The Instance count/sequence to be added in the name of the resource |
| `locationShortName` | string | `` |  | Optional. Short name for the location |
| `azureADOnlyAuthentication` | bool | false  |  | Optional. Enable or Disable AzureADOnlyAuthentication on All Workspace subresource |
| `adminPasswordSecretNameinKV` | String |  |  | Optional. The secret holder name stored in key vault holding admin login password. Used for retreiving secret value (admin password) |
| `managedVirtualNetwork` | String |  |  | Setting this to 'default' will ensure that all compute for this workspace is in a virtual network managed on behalf of the user. |
| `createManagedPrivateEndpoint` | bool | true |  | Create managed private endpoint to this storage account or not |
| `managedResourceGroupName` | string |  |  | Optional. Workspace managed resource group. The resource group name uniquely identifies the resource group within the user subscriptionId. The resource group name must be no longer than 90 characters long, and must be alphanumeric characters (Char.IsLetterOrDigit()) and '-', '_', '(', ')' and'.'. Note that the name cannot end with '.' |
| `publicNetworkAccess` | string | `Enabled` | `Enabled` `Disabled`  | Optional. Enable or Disable public network access to workspace |
| `trustedServiceBypassEnabled` | bool | true |  | Optional. Is trustedServiceBypassEnabled for the workspace|
| `managedVirtualNetworkSettings` | object |  |  | Optional. Managed Virtual Network settings. allowedAadTenantIdsForLinking, linkedAccessCheckOnTargetResource and preventDataExfiltration are available |
| `location` | string | `[resourceGroup().location]` |  | Optional. Location for all resources. |
| `lock` | string | `NotSpecified` | `[CanNotDelete, NotSpecified, ReadOnly]` | Optional. Specify the type of lock. |
| `name` | string |  |  | Required. The name of the server. Use this paramter only in exceptional cases where naming standard is not required|
| `roleAssignments` | array | `[]` |  | Optional. Array of role assignment objects that contain the 'roleDefinitionIdOrName' and 'principalId' to define RBAC role assignments on this resource. In the roleDefinitionIdOrName attribute, you can provide either the display name of the role definition, or its fully qualified ID in the following format: '/providers/Microsoft.Authorization/roleDefinitions/c2f4ef07-c644-48eb-af81-4b1b4947fb11' |
| `appendRoleAssignments` | bool | `True` | `` | Optional. If set to True, Provided values will be inaddition to default values. If false, provided values will replace default values. |
| `securityAlertPolicies` | _[securityAlertPolicies](securityAlertPolicies/readme.md)_ array | `[]` |  | Optional. The security alert policies to create in the server |
| `systemAssignedIdentity` | bool | `False` |  | Optional. Enables system assigned managed identity on the resource. |
| `tags` | object | `{object}` |  | Optional. Tags of the resource. |
| `appendTags` | bool | `True` | `` | Optional. If set to True, Provided tag values will be inaddition to default tags. If false, provided tag values will replace default tags. |
| `sqlAdministratorLogin` | string |  |  | Optional. Login for workspace SQL active directory administrator |
| `adminPasswordSecretNameinKV` | string |  |  | Optional. The secret holder name that is holding ADmin Password as a secret in key vault. secret will be retreived from key vault|
| `purviewResourceId` | string |  |  | Optional. Purview Resource ID |
| `synapseComputeSubnetId` | string |  |  | Optional. Subnet ID used for computes in workspace |
| `setOwnerForSynapse` | bool | true |  | Optional. Owner rights for a user account on a synapse |
| `isNewStorageAccount` | bool |  |  | Optional. If new storage account for data lake is required |
| `isNewFileSystemOnly` | bool |  |  | Optional. If new container for data lake is required |
| `storageAccessTier` | string | `Hot` |  | Optional.Access tier for new data lake storage account |
| `storageAccountType` | string | `Standard_LRS` |  | Optional. Type of data lake storage account |
| `storageSupportsHttpsTrafficOnly` | bool | true |  | Optional. To support hhtps traffic only |
| `storageKind` | string | `StorageV2` |  | Optional. Data lake storage kind|
| `minimumTlsVersion` | string | `TLS1_2` |  | Optional. TLS version for data lake |
| `storageIsHnsEnabled` | bool | True |  | Optional. Hns setting for data lake storage account |
| `defaultDataLakeStorageAccountName` | string |  |  | Optional. Name of Existing stoarge account or New storage account to be created as data lake|
| `defaultDataLakeStorageFilesystemName` | string | `Standard_LRS` |  | Optional. Name of Existing Container  or New Container to be created in data lake |
| `setWorkspaceIdentityRbacOnStorageAccount` | bool |  |  | Optional. If synapse workspace identity should be given access to data lake storage account  |
| `sqlPoolName` | string | `Standard_LRS` |  | Required. Name of the SQL pool |
| `sqlPoolsku` | string | `Standard_LRS` |  | Optional. SQL pool SKU |
| `sqlcollation` | string | `SQL_Latin1_General_CP1_CI_AS` |  | Optional. SQL Collation  |
| `createMode` | string | `default` |  | Optional. SQL pool create mode. Default or Recover  |
| `sqlstorageAccountType` | string | `LRS` |  | Optional. Sql storage account type  |



### Naming parameter

name property applies standard: {prefix}-{location}-{partner}-{environment}-{application}-{sequence}

### Parameter Usage: `roleAssignments`

```bicep
roleAssignments: [
        {
          roleDefinitionIdOrName: 'Reader'
          principalIds: [
              '12345678-1234-1234-1234-123456789012' // object 1
              '78945612-1234-1234-1234-123456789012' // object 2
                ]
        }
        {
          roleDefinitionIdOrName: '/providers/Microsoft.Authorization/roleDefinitions/c2f4ef07-c644-48eb-af81-4b1b4947fb11'
          principalIds: [
              '12345678-1234-1234-1234-123456789012' // object 1
                ]
        }
]
```

### Parameter Usage: `tags`

Tag names and tag values can be provided as needed. A tag can be left without a value.

```bicep
tags: {
        'product-name': 'hub-foundation'
        'data-classification': 'internal'
        'disaster-recovery': 'critical'
        'Environment': 'dev'
        'owner': 'test.user@testcompany.com'
        'customer': 'hub'
        'budget': ''
        'product-start-date': '2021-07-21'
}
```

## Outputs

| Output Name | Type | Description |
| :-- | :-- | :-- |
| `name` | string | The name of the deployed Synapse workspace |
| `resourceID` | string | The resource ID of the deployed Synapse workspace |
| `objectID` | string | The principal ID of the assigned identity. |

## Template references

- [Diagnosticsettings](https://docs.microsoft.com/en-us/azure/templates/Microsoft.Insights/2021-05-01-preview/diagnosticSettings)
- [Locks](https://docs.microsoft.com/en-us/azure/templates/Microsoft.Authorization/2017-04-01/locks)
- [Roleassignments](https://docs.microsoft.com/en-us/azure/templates/Microsoft.Authorization/roleAssignments)
- [Synapse/workspaces](https://docs.microsoft.com/en-us/azure/templates/microsoft.synapse/2021-06-01/workspaces?tabs=bicep)
- [Storage/storageAccounts](https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2021-01-01/storageaccounts?tabs=bicep)
- [Synapse/workspaces/sqlPools](https://docs.microsoft.com/en-us/azure/templates/microsoft.synapse/2021-03-01/workspaces/sqlpools?tabs=bicep)

