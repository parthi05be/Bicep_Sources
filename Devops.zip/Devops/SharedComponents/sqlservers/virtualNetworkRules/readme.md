# SQL Server Vulnerability Assessments `[Microsoft.Sql/servers/vulnerabilityAssessments]`

This module deploys a vulnerability assessment for a SQL server.

## Navigation

- [Resource Types](#Resource-Types)
- [Parameters](#Parameters)
- [Outputs](#Outputs)

## Resource Types

| Resource Type | API Version |
| :-- | :-- |
| `Microsoft.Sql/servers/vulnerabilityAssessments` | [2021-11-01-preview](https://docs.microsoft.com/en-us/azure/templates/Microsoft.Sql/2021-11-01-preview/servers/vulnerabilityAssessments) |

## Parameters

**Required parameters**
| Parameter Name | Type | Description |
| :-- | :-- | :-- |
| `name` | string | The name of the vulnerability assessment. |
| `serverName` | string | The Name of SQL Server. |

**Optional parameters**
| Parameter Name | Type | Default Value | Description |
| :-- | :-- | :-- | :-- |
| `enableDefaultTelemetry` | bool | `True` | Enable telemetry via the Customer Usage Attribution ID (GUID). |
| `recurringScansEmails` | array | `[]` | Specifies an array of email addresses to which the scan notification is sent. |
| `recurringScansEmailSubscriptionAdmins` | bool | `False` | Specifies that the schedule scan notification will be is sent to the subscription administrators. |
| `recurringScansIsEnabled` | bool | `False` | Recurring scans state. |
| `vulnerabilityAssessmentsStorageAccountId` | string | `''` | A blob storage to hold the scan results. |


## Outputs

| Output Name | Type | Description |
| :-- | :-- | :-- |
| `name` | string | The name of the deployed vulnerability assessment. |
| `resourceGroupName` | string | The resource group of the deployed vulnerability assessment. |
| `resourceId` | string | The resource ID of the deployed vulnerability assessment. |
