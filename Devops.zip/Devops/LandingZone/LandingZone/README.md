# Introduction 
The LandingZone Repo is the Repo from where we orchestrate the deployments, we refer to the artifacts created from the Modules present in [sharedComponents Repo](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents).
the orchestration is done in a way that the pipeline rochestrates the deployments at different scopes. 
 - Subscription Level
 - Resource Group Level

we further break down the deployments at the template level into various use cases(we use modules to do this): 
- Networking
- SharedComponents deployment(Keyvaults, Log analytics worksapces)
- Recovery Services Vaults.
- Data Services.

Under each module we can see that there are references to the Modules/artifacts which have been downloaded as part of the deployment pipeline, 
we pass the required parameters to these modues to deploy the resources.

The pipelines have also been divided into 2 main folders: 
- ACF: We sepereted the deployment to hub and spokek as tehre a re reusable and repeated respource deployments in all the spokes while the hub is a 
  subscription with resources specific to HUb only.(for e.g., Virtual Wan, Firewall, Virtual Hubs etc.)
    1. Hub- pipeline (to deploy to the ave-cor-Network subscription which is the Hub)
    2. SpokeDeployment Pipeline (to deploy to all the spokes)

- Data Pipelines (Contain Synapse CI/CD pipelines)

#For deep dive into the Documentation please view the below link.
##[AVEHEALTH | Platform Automation and DevOps Documentation](https://mitsui365apc.sharepoint.com/:w:/r/sites/AveHealthAzurePlatformDeployment/Shared%20Documents/General/Engagement%20Governance/Delivery/Sprint%206/ACF-Network-KT/avehealth%20-%20Platform%20automation%20and%20DevOps-%20IaC%20-%20Documentation.docx?d=w529abf79ba2040bfaa8677d6e11defb0&csf=1&web=1&e=OboaZW)]


# Referance Documentation
- [aks](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents?path=/aks/readme.md)
- [applicationgateways](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents?path=/applicationgateways/readme.md)
- [azurefirewalls](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents?path=/azurefirewalls/readme.md)
- [bastionhosts](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents?path=/bastionhosts/readme.md)
- etc.
###Other Resources can be found at [sharedComponents Repo](https://dev.azure.com/AveHealth/AveHealth%20Platform/_git/SharedComponents), [Module]-> readme.md

