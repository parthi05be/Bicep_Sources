# Databricks notebook source
# DBTITLE 1,create database
# MAGIC %sql
# MAGIC create database hivemetastore

# COMMAND ----------

# DBTITLE 1,Create Table
# MAGIC %sql
# MAGIC create table hivemetastore.HiveSampleTable
# MAGIC (class_hive string,
# MAGIC class_hive_description string
# MAGIC )
# MAGIC --ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
# MAGIC ROW FORMAT SERDE 'com.bizo.hive.serde.csv.CSVSerde'
# MAGIC WITH SERDEPROPERTIES
# MAGIC ("separatorChar" = ",",
# MAGIC "quoteChar" = "\""
# MAGIC )
# MAGIC LOCATION
# MAGIC '/FileStore/tables/'

# COMMAND ----------

# MAGIC %sql
# MAGIC create database hivemetastoretest

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC drop database hivemetastoretest