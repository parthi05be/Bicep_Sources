# Databricks notebook source
# DBTITLE 1,Mount ADLS path
spark.conf.set(
  "fs.azure.account.key.aveseadevstdata002.dfs.core.windows.net",
   dbutils.secrets.get(scope="avehealthdatabricksscope",key="storageaccountkey")  
)



# COMMAND ----------

# DBTITLE 1,Read the csv file
# File location and type
file_location = "abfss://gold@aveseadevstdata002.dfs.core.windows.net/userinfodata.csv"
file_type = "csv"

# CSV options
infer_schema = "true"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)


# COMMAND ----------

# DBTITLE 1,create spark sql table from the dataframe
# Create a view or table

temp_table_name = "userinfotable"
df.createOrReplaceTempView(temp_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from userinfotable

# COMMAND ----------



# COMMAND ----------

delta_table_name = "hivemetastore.userinfotable"
df.write.format("delta").saveAsTable(delta_table_name)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hivemetastore.userinfotable

# COMMAND ----------

