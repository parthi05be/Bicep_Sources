##################################################################################################################
########### Initialize folder structure in to store ingested data for each data source per metadata definition in the source onboarding Excel file
##################################################################################################################

param(
    [parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Specifies file path of the source on-boarding Excel file which contains metadata control data.")]
    [string]$SourceOnBoardingFilePath,

    [parameter(Mandatory=$true, HelpMessage="Specifies name of the Azure Storage account which the folder structure will be created. In case Storage Account name [which is DestinationControl1 column] is not specified in the metadata control defintion file for a data source entry, this script will create the folder structure for holding ingested data in this default Storage Account.")]
    [string]$DefaultStorageAccountName,

    [parameter(Mandatory=$true, HelpMessage="Specifies name of the file system (container) in the Azure Storage account which the folder structure will be created. In case file system (contain) name [which is DestinationControl2 column] is not specified in the metadata control defintion file for a data source entry, this script will create the folder structure for holding ingested data in this default file system (container).")]
    [string]$DefaultFileSystemName,

    [parameter(Mandatory=$true, HelpMessage="Specifies folder path for the CreateADLSGen2Folder.ps1 script which is going to be executed by this script.")]
    [string]$CreateADLSGEn2FolderScriptFolderPath
)
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
# Install PSExcel module
Install-module PSExcel -Confirm:$false
import-module PSExcel

# Begin work
$path = $SourceOnBoardingFilePath
$metadataRows = new-object System.Collections.ArrayList

foreach ($record in (Import-XLSX -Path $path -Sheet 'operation.MetadataTableControl'))
{
    Write-Host "------------------------------"
    Write-Host $record
    # Only create folder structure for metadata control entry that specifies Datalake as desintation object type
    if ($record.DestinationTypeofObject -eq "Datalake" -and [int]($record.Active) -eq 1)
    {
        $metadataControlID = $record.MetadataControlID
        # For ADLS Gen 2 as destination such as RAW zone
        # DestinationControl1 is Storage Account name
        # DestinationControl2 is File System (Container) name
        # DestinationControl3 is Folder Path
        # DestinationControl4 is File Name or File Name Pattern
        $destStorageAccountName = (&{if($record.DestinationControl1.Length -gt 0) { $record.DestinationControl1 } else { $DefaultStorageAccountName }})
        $destFileSystemContainerName = (&{if($record.DestinationControl2.Length -gt 0) { $record.DestinationControl2 } else { $DefaultFileSystemName }})
        if($record.DestinationControl3.Length -gt 0) {
            $destFolder = $record.DestinationControl3
        }
        if(-Not $destFolder.EndsWith("/"))
        {
            $destFolder+="/"
        }
        if (-not $destFolder.StartsWith("global") -and -not $destFolder.StartsWith("/"))
        {
            # Assumming then that the first segment of the folder path is the country folder according to the agreed folder structure design
            # Then, we need to create the folder country/common too.
            $commonFolderPath = $destFolder.Split("/")[0] + "/" + "common"
        }
        
        # $destStorageAccountName+=".privatelink"

        Write-Host "Destination for MetadataControlID " $metadataControlID " is Datalake."
        Write-Host "Will pre-create folder structure at Storage Account: " $destStorageAccountName " File System (Container): " $destFileSystemContainerName " Folders to create: " $destFolder

        # Creat folder structure using CreateADLSGen2Folder.ps1 script
        
        & "$CreateADLSGEn2FolderScriptFolderPath\CreateADLSGen2Folder.ps1" -StorageAccountName $destStorageAccountName -FileSystemName $DefaultFileSystemName -FolderPath $destFolder
        & "$CreateADLSGEn2FolderScriptFolderPath\CreateADLSGen2Folder.ps1" -StorageAccountName $destStorageAccountName -FileSystemName $DefaultFileSystemName -FolderPath $commonFolderPath
    }
}