﻿CREATE TABLE UserInfo (
  auto_id int NOT NULL IDENTITY(1, 1),
  ID int,
  Name nvarchar(255) default NULL,
  Address nvarchar(255) default NULL,
  MobileNo nvarchar(100) default NULL,
  Email nvarchar(255) default NULL,
  BOD varchar(255)
);