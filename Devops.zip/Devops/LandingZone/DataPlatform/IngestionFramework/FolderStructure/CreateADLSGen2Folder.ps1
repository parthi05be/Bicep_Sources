##################################################################################################################
########### Create container and folder structure on the storage account
##################################################################################################################

[CmdletBinding(DefaultParameterSetName = 'All')]
param(
    [parameter(Mandatory = $true, ParameterSetName = 'All', Position = 0, ValueFromPipeline = $true)]
    [parameter(Mandatory = $true, ParameterSetName = 'UseAccountKey', Position = 0)]
    [parameter(HelpMessage = "Specifies an Azure Storage account name.")]
    [string]$StorageAccountName,

    [parameter(Mandatory = $true, ParameterSetName = 'UseAccountKey', HelpMessage = "Specifies an Azure Storage account key to authenticate to the Storage account.", Position = 1)]
    [string]$StorageAccountKey,

    [parameter(Mandatory = $true, ParameterSetName = 'All', Position = 1)]
    [parameter(Mandatory = $true, ParameterSetName = 'UseAccountKey', Position = 2)]
    [parameter(HelpMessage = "Specifies an ADLS Gen2 file system name e.g. raw. If the file system (container) doesn't exist, it'll be created.")]
    [string]$FileSystemName, 

    [parameter(Mandatory = $true, ParameterSetName = 'All', Position = 2)]
    [parameter(Mandatory = $true, ParameterSetName = 'UseAccountKey', Position = 3)]
    [parameter(HelpMessage = "Specifies a folder path separated with / e.g. sg/mt_elizabeth_hosp/microtel_crm/billing.")]
    [string]$FolderPath
)
# Install Az.Storage module
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
Install-Module -Name Az.Storage -AllowClobber
Import-Module -Name Az.Storage

##Connect to your Azure account (local test)
#Connect-AzAccount -TenantId
if ($StorageAccountKey) {
    $ctx = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
    Write-Host -ForegroundColor Yellow "Use Storage account key authentication."   
}
else {  
    $ctx = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount
    Write-Host -ForegroundColor Yellow "Use connected user account authentication."
}
 
##################################################################################################################
##create container in storage account 
##TESTING ##
Write-Host 'ctx'
Write-output $ctx

##END TESTING ##
if (Get-AzStorageContainer -Name $FileSystemName.trim() -Context $ctx -ErrorAction SilentlyContinue) {  
    Write-Host $FileSystemName.trim() "- file system already exists." 
}  
else {  
    Write-Host -ForegroundColor Yellow $FileSystemName.trim() "- file system does not exist."   
    ## Create a new Azure Storage Account  
    New-AzStorageContainer -Name $FileSystemName.trim() -Context $ctx
    Write-Host -ForegroundColor Yellow $FileSystemName.trim() "- file system created in " $StorageAccountName " Storage account."
}

##################################################################################################################

##create folder in data lake
$dir = $FolderPath.Trim()
if (-Not $FolderPath.EndsWith("/")) {
    $dir = $dir + "/"
}

if (Get-AzDataLakeGen2Item -Context $ctx -FileSystem $FileSystemName -Path $dir -ErrorAction SilentlyContinue) {
    Write-Host $FolderPath "- folder path already exists."
}
else {
    Write-Host -ForegroundColor Yellow $FolderPath "- folder path does not exist."
    ## Create a folder structure
    New-AzDataLakeGen2Item -Context $ctx -FileSystem $FileSystemName -Path $dir -Directory
    Write-Host -ForegroundColor Yellow $FolderPath "- folder path created."
}

##################################################################################################################