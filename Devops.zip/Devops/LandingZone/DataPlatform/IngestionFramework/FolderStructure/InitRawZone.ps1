##################################################################################################################
########### Initialize raw container and static folder structure (global and common folders)
##################################################################################################################

[CmdletBinding(DefaultParameterSetName = 'All')]
param(
    [parameter(Mandatory=$true, ValueFromPipeline=$true, HelpMessage="Specifies an Azure Storage account name.")]
    [string]$StorageAccountName,

    [parameter(Mandatory=$false, HelpMessage="Specifies an Azure Storage account key to authenticate to the Storage account.")]
    [string]$StorageAccountKey
)

if ($StorageAccountKey) {
    .\CreateADLSGen2Folder.ps1 -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey -FileSystemName "raw" -FolderPath "global/common"
}
else
{
    .\CreateADLSGen2Folder.ps1 -StorageAccountName $StorageAccountName -FileSystemName "raw" -FolderPath "global/common"
}