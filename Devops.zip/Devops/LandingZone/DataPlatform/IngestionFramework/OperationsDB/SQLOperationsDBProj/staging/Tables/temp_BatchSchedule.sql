﻿CREATE TABLE [staging].[temp_BatchSchedule] (
    [BatchScheduleID] INT           NULL,
    [ScheduleName]    VARCHAR (100) NULL,
    [Active]          BIT           NULL
);

