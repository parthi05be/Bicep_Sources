﻿CREATE TABLE [staging].[temp_Hospital] (
    [HospitalID]   INT           NULL,
    [HospitalName] VARCHAR (100) NULL,
    [Country]      VARCHAR (100) NULL,
    [Active]       BIT           NULL
);

