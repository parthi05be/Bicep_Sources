﻿CREATE TABLE [staging].[temp_SourceSystem] (
    [SourceSystemID] INT           NULL,
    [SourceName]     VARCHAR (500) NULL,
    [Active]         BIT           NULL
);

