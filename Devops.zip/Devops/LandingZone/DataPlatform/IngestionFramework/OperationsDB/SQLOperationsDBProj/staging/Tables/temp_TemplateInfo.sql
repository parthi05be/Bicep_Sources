﻿CREATE TABLE [staging].[temp_TemplateInfo] (
    [TemplateInfoID] INT           NULL,
    [TemplateName]   VARCHAR (500) NOT NULL,
    [Active]         BIT           NULL
);



