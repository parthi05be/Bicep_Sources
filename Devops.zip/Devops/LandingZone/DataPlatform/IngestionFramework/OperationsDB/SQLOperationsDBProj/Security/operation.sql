﻿CREATE SCHEMA [operation]
    AUTHORIZATION [dbo];

















