﻿-- Procedure Name: [operation].[BatchSchedule_Upsert]
-- Purpose       : This procedure will accept all the parameters and insert  or update into BatchSchedule. 
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE procedure [operation].[BatchSchedule_Upsert]
as
begin
MERGE operation.BatchSchedule AS TARGET
USING staging.temp_BatchSchedule AS SOURCE 
ON (TARGET.[ScheduleName]= SOURCE.[ScheduleName]) 

WHEN MATCHED 
THEN UPDATE SET TARGEt.Active=SOURCE.Active,TARGEt.ModifiedOn=GETUTCDATE(), ModifiedBy=SYSTEM_USER

WHEN NOT MATCHED BY TARGET 
THEN INSERT ([ScheduleName],Active,ModifiedBy,ModifiedOn) VALUES (SOURCE.[ScheduleName],SOURCE.Active,SYSTEM_USER,GETUTCDATE());
end