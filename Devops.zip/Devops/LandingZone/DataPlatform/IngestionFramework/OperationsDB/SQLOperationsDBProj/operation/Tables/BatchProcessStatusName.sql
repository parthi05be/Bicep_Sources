﻿CREATE TABLE [operation].[BatchProcessStatusName] (
    [BatchProcessStatusNameID] INT           NOT NULL,
    [ProcessStatusName]        VARCHAR (100) NULL,
    [ModifiedBy]               VARCHAR (500) CONSTRAINT [DF_user] DEFAULT (user_name()) NULL,
    [ModifiedOn]               DATETIME      NULL,
    CONSTRAINT [PK_BatchProcessStatusName_BatchProcessStatusNameID] PRIMARY KEY CLUSTERED ([BatchProcessStatusNameID] ASC)
);





