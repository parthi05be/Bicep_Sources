﻿CREATE TABLE [operation].[BatchSchedule] (
    [BatchScheduleID] INT           IDENTITY (1, 1) NOT NULL,
    [ScheduleName]    VARCHAR (100) NOT NULL,
    [Active]          BIT           NOT NULL,
    [ModifiedBy]      VARCHAR (500) NULL,
    [ModifiedOn]      DATETIME      NULL,
    CONSTRAINT [PK_BatchSchedule_BatchScheduleID] PRIMARY KEY CLUSTERED ([BatchScheduleID] ASC)
);





