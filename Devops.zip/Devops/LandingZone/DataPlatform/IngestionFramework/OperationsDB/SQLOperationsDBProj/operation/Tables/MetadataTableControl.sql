﻿CREATE TABLE [operation].[MetadataTableControl] (
    [MetadataControlID]             INT            IDENTITY (1, 1) NOT NULL,
    [SourceSystemID]                INT            NOT NULL,
    [HospitalID]                    INT            NOT NULL,
    [BatchScheduleID]               INT            NOT NULL,
    [TemplateinfoID]                INT            NOT NULL,
    [GroupLoad]                     VARCHAR (50)   NULL,
    [TableGroupNumber]              INT            NULL,
    [SourceTypeofObject]            VARCHAR (100)  NULL,
    [SourceKeyVaultURI]             VARCHAR (100)  NULL,
    [SourceKeyVaultSecretName]      VARCHAR (100)  NULL,
    [SourceControl1]                VARCHAR (1000) NULL,
    [SourceControl2]                VARCHAR (1000) NULL,
    [SourceControl3]                VARCHAR (1000) NULL,
    [SourceControl4]                VARCHAR (1000) NULL,
    [SourceControl5]                VARCHAR (1000) NULL,
    [SourceControl6]                VARCHAR (1000) NULL,
    [DestinationTypeofObject]       VARCHAR (50)   NULL,
    [DestinationKeyVaultURI]        VARCHAR (100)  NULL,
    [DestinationKeyVaultSecretName] VARCHAR (100)  NULL,
    [DestinationControl1]           VARCHAR (1000) NULL,
    [DestinationControl2]           VARCHAR (1000) NULL,
    [DestinationControl3]           VARCHAR (1000) NULL,
    [DestinationControl4]           VARCHAR (1000) NULL,
    [DestinationControl5]           VARCHAR (1000) NULL,
    [DestinationControl6]           VARCHAR (1000) NULL,
    [Active]                        BIT            NULL,
    [DataInserted]                  DATETIME       NULL,
    [DataUpdated]                   DATETIME       NULL,
    [Delimiter]                     VARCHAR (50)   NULL,
    [DateFormat]                    VARCHAR (100)  NULL,
    [ModifiedBy]                    VARCHAR (500)  NULL,
    [ModifiedOn]                    DATETIME       NULL,
    CONSTRAINT [FK_BatchScheduleID] FOREIGN KEY ([BatchScheduleID]) REFERENCES [operation].[BatchSchedule] ([BatchScheduleID]),
    CONSTRAINT [FK_Hospital] FOREIGN KEY ([HospitalID]) REFERENCES [operation].[Hospital] ([HospitalID]),
    CONSTRAINT [FK_SourceSystem] FOREIGN KEY ([SourceSystemID]) REFERENCES [operation].[SourceSystem] ([SourceSystemID]),
    CONSTRAINT [FK_TemplateinfoID] FOREIGN KEY ([TemplateinfoID]) REFERENCES [operation].[TemplateInfo] ([TemplateInfoID])
);









