﻿----------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[AuditLogDetails_Upsert] 
-- Purpose       : This procedure will accept all the parameters and will log the details of ingestion into the auditLog table
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [operation].[AuditLogDetails_Upsert]
	(
	@InsertUpsert [smallint],
	@AuditLogID [int] NULL,
	@MetadataControlID int ,
	
	@BatchProcessStatusNameID [smallint],
	
	@DataRead [decimal](19,4) NULL,
	@DataWritten [decimal](19,4) NULL,
	@Throughput [decimal](19,4) NULL,
	@RowsWritten [int] NULL, 
	@BatchScheduleID int,
	
	@FilesorrowsRead Varchar(100),
	@FilesorrowsWrite Varchar(100),
	@Errormessage varchar(max),
	@PipelineRunId varchar(100)
	)

AS

/*
--Execution execution example:
@InsertUpsert: 1 Insert, 2 Upsert for a group of tables, 3 Upsert for a specific table

EXECUTE [operation].[BatchProcess_Upsert]

*/

IF @InsertUpsert = 1
BEGIN
	--Create process table structure for an especific project
	BEGIN TRANSACTION;		
		INSERT INTO
			[operation].auditlogdetails
			(

AuditLogID
,MetadataControlID
,BatchProcessStatusNameID
,StartTime
,EndTime
,DurationInSeconds
,DataRead
,DataWritten
,Throughput
,RowsWritten
,IsSucceed
,[Files/Rowsread]
,[Files/Rowswrite]
,ErrorMessage,
PipelineRunId
			)
		SELECT
			@AuditLogID					AS AuditLogID,
			MTC.MetadataControlID				AS BatchScheduleID,
			
			0								AS BatchProcessStatusNameID,--Status 0 = Waiting to process
			
			NULL							AS StartTime,
			NULL							AS EndTime,
			NULL							AS DurationInSeconds,
			NULL							AS DataRead,
			NULL							AS DataWritten,
			NULL							AS Throughput,
			NULL							AS RowsWritten,
			1								AS ActiveInBatchProcess,
			NULL							AS  [Files/Rowsread],
            NULL							 AS  [Files/Rowswrite],
			NULL                            As ErrorMesssage,
			@PipelineRunId as PipelineRunId
			
		FROM
			[operation].[MetadataTableControl] MTC
		WHERE
			MTC.Active = 1
			AND MTC.BatchScheduleID = @BatchScheduleID

	COMMIT;
	--END - Create process table structure for an especific project
END

IF @InsertUpsert = 2 AND @BatchProcessStatusNameID = 10
BEGIN
	--UPDATE process table structure (for a group of tables) for running process
	BEGIN TRANSACTION;
		UPDATE
			[operation].Auditlogdetails
		SET
			[BatchProcessStatusNameID] = @BatchProcessStatusNameID,
			[StartTime] = GETDATE()		
		WHERE
			[AuditLogID] = @AuditLogID
			
		
			AND  MetadataControlID=@MetadataControlID
				

	COMMIT;
	--END - UPDATE process table structure (for a group of tables) for running process
END

IF @InsertUpsert = 2 AND @BatchProcessStatusNameID = 20
BEGIN
	--UPDATE process table structure (for a group of tables)
	BEGIN TRANSACTION;
		UPDATE
			[operation].AuditLogDetails
		SET
			[BatchProcessStatusNameID] = @BatchProcessStatusNameID,
			[StartTime]=isnull(StartTime,Getdate()),
			[EndTime] = GETDATE(),
			[DurationInSeconds] = DATEDIFF(SS,[StartTime],GETDATE()),
			[Files/Rowsread]=@FilesorrowsRead,
			[Files/Rowswrite]=@FilesorrowsWrite,
			ErrorMessage=@Errormessage
		WHERE
			[AuditLogID] = @AuditLogID
			and MetadataControlID=@MetadataControlID

		--UPDATE residual tables for a particular "TableGroupNumber" to stop batch processing 
		UPDATE
			[operation].AuditLogDetails
		SET
			IsSucceed =case when ErrorMessage is null then 1
			else 0 end 
		WHERE
			AuditLogID = @AuditLogID
			
		--END - UPDATE residual tables for a particular "TableGroupNumber" to stop batch processing

	COMMIT;
	--END - UPDATE process table structure (for a specific table)
END

IF @InsertUpsert = 2 AND @BatchProcessStatusNameID = 40
BEGIN
	--UPDATE process table structure (for a group of tables)
	BEGIN TRANSACTION;
		UPDATE
			[operation].AuditLogDetails
		SET
			[BatchProcessStatusNameID] = @BatchProcessStatusNameID,
			[EndTime] = GETDATE(),
			[DurationInSeconds] = DATEDIFF(SS,[StartTime],GETDATE()),
			[DataRead] = @DataRead,
			[DataWritten] = @DataWritten,
			[Throughput] = @Throughput,
			[RowsWritten] = @RowsWritten,
			IsSucceed = 1,
			[Files/Rowsread]=@FilesorrowsRead,
			[Files/Rowswrite]=@FilesorrowsWrite,
			ErrorMessage=@Errormessage
		WHERE
			[AuditLogID] = @AuditLogID
		AND MetadataControlID=@MetadataControlID

	COMMIT;
	--END - UPDATE process table structure (for a specific table)
END