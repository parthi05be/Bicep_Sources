﻿CREATE TABLE [operation].[TemplateInfo] (
    [TemplateInfoID] INT           IDENTITY (1, 1) NOT NULL,
    [TemplateName]   VARCHAR (500) NOT NULL,
    [Active]         BIT           NULL,
    [ModifiedBy]     VARCHAR (500) NULL,
    [ModifiedOn]     DATETIME      NULL,
    CONSTRAINT [PK_TemplateInfoID] PRIMARY KEY CLUSTERED ([TemplateInfoID] ASC)
);







