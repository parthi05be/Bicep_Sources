﻿--------------------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[Hospital_Upsert]
-- Purpose       : This procedure will accept all the parameters and insert  or update into Hospital table. 
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------


CREATE procedure [operation].[Hospital_Upsert]
as
begin

IF object_id ('Tempdb..#t') IS NOT NULL
DROP TABLE #t


SELECT a.*,
       row_number() OVER (PARTITION BY a.HospitalName,a.country
                          ORDER BY a.Country) AS rn

						  into #t

						  from staging.[temp_Hospital] a

MERGE operation.Hospital AS TARGET
USING (select * from #t where rn=1 ) AS SOURCE 
ON   (TARGET.HospitalName= SOURCE.HospitalName and TARGET.Country=SOURCE.Country) 

WHEN MATCHED 
THEN UPDATE SET TARGET.Active=SOURCE.Active,TARGEt.ModifiedOn=GETUTCDATE(), ModifiedBy=SYSTEM_USER

WHEN NOT MATCHED BY TARGET 
THEN INSERT (HospitalName,Country,Active,ModifiedBy,ModifiedOn) VALUES (SOURCE.HospitalName,SOURCE.Country,SOURCE.Active,SYSTEM_USER,GETUTCDATE());
end