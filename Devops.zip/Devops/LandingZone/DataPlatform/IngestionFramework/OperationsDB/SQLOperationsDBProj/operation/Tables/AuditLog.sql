﻿CREATE TABLE [operation].[AuditLog] (
    [AuditLogID]               INT           IDENTITY (1, 1) NOT NULL,
    [BatchProcessStatusNameID] INT           NULL,
    [BatchScheduleID]          VARCHAR (100) NULL,
    [StartTime]                DATETIME      NULL,
    [EndTime]                  DATETIME      NULL,
    [DurationInSeconds]        INT           NULL,
    [PipelineRunId]            VARCHAR (100) NULL,
    [PipelineName]             VARCHAR (100) NULL,
    [TriggerId]                VARCHAR (100) NULL,
    [TriggerName]              VARCHAR (100) NULL,
    [TriggerType]              VARCHAR (100) NULL,
    [IsSucceed]                BIT           NULL,
    CONSTRAINT [PK_AuidtLog_AuidtLogID] PRIMARY KEY CLUSTERED ([AuditLogID] ASC)
);









