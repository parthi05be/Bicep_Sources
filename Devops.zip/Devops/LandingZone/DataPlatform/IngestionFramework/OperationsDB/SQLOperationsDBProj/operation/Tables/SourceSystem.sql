﻿CREATE TABLE [operation].[SourceSystem] (
    [SourceSystemID] INT           IDENTITY (1, 1) NOT NULL,
    [SourceName]     VARCHAR (500) NULL,
    [Active]         BIT           NULL,
    [ModifiedBy]     VARCHAR (500) NULL,
    [ModifiedOn]     DATETIME      NULL,
    CONSTRAINT [PK_SourceSystem_SourceSystemID] PRIMARY KEY CLUSTERED ([SourceSystemID] ASC)
);







