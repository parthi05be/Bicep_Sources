﻿----------------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[[SourceSystem_Upsert]]
-- Purpose       : This procedure will accept all the parameters and insert or update into SourceSystem table. 
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE procedure [operation].[SourceSystem_Upsert]
as
begin
MERGE operation.[SourceSystem] AS TARGET
USING staging.[temp_SourceSystem] AS SOURCE 
ON (TARGET.SourceName= SOURCE.SourceName) 
WHEN MATCHED 
THEN UPDATE SET TARGEt.Active=SOURCE.Active,TARGEt.ModifiedOn=GETUTCDATE(), ModifiedBy=SYSTEM_USER

WHEN NOT MATCHED BY TARGET 
THEN INSERT (SourceName,Active,ModifiedBy,ModifiedOn) VALUES (SOURCE.SourceName, SOURCE.Active,SYSTEM_USER,GETUTCDATE());
end