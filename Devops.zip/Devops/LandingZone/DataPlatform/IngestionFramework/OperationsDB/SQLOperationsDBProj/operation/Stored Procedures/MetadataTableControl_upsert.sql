﻿----------------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[MetadataTableControl_upsert]
-- Purpose       : This procedure will accept all the parameters and insert or update into MetadataControl table. 
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE PROC [operation].[MetadataTableControl_upsert]
AS
BEGIN
IF object_id ('Tempdb..#t') IS NOT NULL
DROP TABLE #t

SELECT a.*,
       row_number() OVER (PARTITION BY a.sourceName,
                                       a.HospitalName,
                                       a.ScheduleName,
									   a.TemplateName,
									     a.SourceControl2,
                                        a.SourceControl3,
                                       a.SourceControl4,
                                       a.SourceControl5
                          ORDER BY a.[CreatedBy]) AS rn,
                         b.SourceSystemID,
                         c.TemplateInfoID,
                         d.BatchScheduleID,
                         e.HospitalID INTO #t
FROM staging.temp_MetadataTableControl a
JOIN operation.sourcesystem b ON a.sourcename=b.sourcename
JOIN operation.templateinfo c ON c.templatename=a.templatename
JOIN operation.batchschedule d ON d.schedulename=a.schedulename
JOIN Operation.Hospital e ON e.HospitalName=a.HospitalName
MERGE [operation].[MetadataTableControl] AS TARGET USING
  (SELECT *
   FROM #t
   WHERE rn=1 ) SOURCE ON (TARGET.BatchScheduleID= SOURCE.BatchScheduleID
                           AND TARGET.SourceSystemID= SOURCE.SourceSystemID
                           AND TARGET.HospitalID= SOURCE.HospitalID
                           AND TARGET.TemplateinfoID= SOURCE.TemplateinfoID
                           AND TARGET.SourceControl3= SOURCE.SourceControl3
                           AND TARGET.SourceControl4= SOURCE.SourceControl4) WHEN MATCHED THEN
UPDATE
SET TARGEt.GroupLoad=SOURCE.GroupLoad,
    TARGEt.TableGroupNumber=SOURCE.TableGroupNumber,
    TARGEt.SourceTypeofObject=SOURCE.SourceTypeofObject,
    TARGEt.SourceKeyVaultURI=SOURCE.SourceKeyVaultURI,
    TARGEt.SourceKeyVaultSecretName=SOURCE.SourceKeyVaultSecretName,
    TARGEt.[SourceControl1]=SOURCE.[SourceControl1],
    TARGEt.[SourceControl2]=SOURCE.[SourceControl2],
    TARGEt.[SourceControl5]=SOURCE.[SourceControl5],
    TARGEt.[SourceControl6]=SOURCE.[SourceControl6],
    TARGEt.DestinationTypeofObject=SOURCE.DestinationTypeofObject,
    TARGEt.DestinationKeyVaultURI=SOURCE.DestinationKeyVaultURI,
    TARGEt.DestinationKeyVaultSecretName=SOURCE.DestinationKeyVaultSecretName,
    TARGEt.DestinationControl1=SOURCE.DestinationControl1,
    TARGEt.DestinationControl2=SOURCE.DestinationControl2,
    TARGEt.DestinationControl3=SOURCE.DestinationControl3,
    TARGEt.DestinationControl4=SOURCE.DestinationControl4,
    TARGEt.DestinationControl5=SOURCE.DestinationControl5,
    TARGEt.DestinationControl6=SOURCE.DestinationControl6,
    TARGEt.Active=SOURCE.Active,
    TARGEt.DataInserted=SOURCE.DataInserted,
    TARGEt.DataUpdated=SOURCE.DataUpdated,
    TARGEt.Delimiter=SOURCE.Delimiter,
    TARGEt.DateFormat=SOURCE.DateFormat,
    TARGEt.ModifiedBy=SOURCE.CreatedBy 
	
	WHEN NOT MATCHED BY TARGET THEN
INSERT ([SourceSystemID],
        [HospitalID],
        [BatchScheduleID],
        [TemplateinfoID],
        [GroupLoad],
        [TableGroupNumber],
        [SourceTypeofObject],
        [SourceKeyVaultURI],
        [SourceKeyVaultSecretName],
        [SourceControl1],
        [SourceControl2],
        [SourceControl3],
        [SourceControl4],
        [SourceControl5],
        [SourceControl6],
        [DestinationTypeofObject],
        [DestinationKeyVaultURI],
        [DestinationKeyVaultSecretName],
        [DestinationControl1],
        [DestinationControl2],
        [DestinationControl3],
        [DestinationControl4],
        [DestinationControl5],
        [DestinationControl6],
        [Active],
        [DataInserted],
        [DataUpdated],
        [Delimiter],
        [DateFormat],
        [ModifiedBy],
		ModifiedOn
		)
VALUES (SOURCE.[SourceSystemID], SOURCE.[HospitalID],SOURCE.[BatchScheduleID],SOURCE.[TemplateinfoID],SOURCE.[GroupLoad],SOURCE.[TableGroupNumber], SOURCE.[SourceTypeofObject],SOURCE.[SourceKeyVaultURI],SOURCE.[SourceKeyVaultSecretName],SOURCE.[SourceControl1], SOURCE.[SourceControl2],SOURCE.[SourceControl3],SOURCE.[SourceControl4],SOURCE.[SourceControl5],SOURCE.[SourceControl6], SOURCE.[DestinationTypeofObject],SOURCE.[DestinationKeyVaultURI],SOURCE.[DestinationKeyVaultSecretName],SOURCE.[DestinationControl1],SOURCE.[DestinationControl2],SOURCE.[DestinationControl3],SOURCE.[DestinationControl4],SOURCE.[DestinationControl5],SOURCE.[DestinationControl6],SOURCE.[Active],SOURCE.[DataInserted],SOURCE.[DataUpdated], SOURCE.[Delimiter],SOURCE.[DateFormat],SYSTEM_USER
,GETUTCDATE()
);

end