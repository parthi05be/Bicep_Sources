﻿CREATE TABLE [operation].[AuditLogDetails] (
    [AuditLogDetailsID]        INT             IDENTITY (1, 1) NOT NULL,
    [AuditLogID]               INT             NULL,
    [MetadataControlID]        INT             NULL,
    [BatchProcessStatusNameID] INT             NULL,
    [StartTime]                DATETIME        NULL,
    [EndTime]                  DATETIME        NULL,
    [DurationInSeconds]        INT             NULL,
    [DataRead]                 DECIMAL (19, 4) NULL,
    [DataWritten]              DECIMAL (19, 4) NULL,
    [Throughput]               DECIMAL (19, 4) NULL,
    [RowsWritten]              INT             NULL,
    [IsSucceed]                BIT             NULL,
    [Files/Rowsread]           INT             NULL,
    [Files/Rowswrite]          INT             NULL,
    [ErrorMessage]             VARCHAR (MAX)   NULL,
    [PipelineRunId]            VARCHAR (100)   NULL,
    CONSTRAINT [FK_AuditLogDetails_AuidtLogID] FOREIGN KEY ([AuditLogID]) REFERENCES [operation].[AuditLog] ([AuditLogID]),
    CONSTRAINT [FK_AuditLogDetails_BatchProcessStatusNameID] FOREIGN KEY ([BatchProcessStatusNameID]) REFERENCES [operation].[BatchProcessStatusName] ([BatchProcessStatusNameID])
);









