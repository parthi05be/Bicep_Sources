﻿----------------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[TemplateInfo_Upsert]
-- Purpose       : This procedure will accept all the parameters and insert or update into TemplateInfo table. 
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version

  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE procedure [operation].[TemplateInfo_Upsert]
as
begin
MERGE operation.TemplateInfo AS TARGET
USING staging.temp_TemplateInfo AS SOURCE 
ON (TARGET.[TemplateName]= SOURCE.[TemplateName]) 

WHEN MATCHED 
THEN UPDATE SET TARGEt.Active=SOURCE.Active,TARGEt.ModifiedOn=GETUTCDATE(), ModifiedBy=SYSTEM_USER

WHEN NOT MATCHED BY TARGET 
THEN INSERT ([TemplateName],Active,ModifiedBy,ModifiedOn) VALUES (SOURCE.[TemplateName],SOURCE.Active,SYSTEM_USER,GETUTCDATE());
end