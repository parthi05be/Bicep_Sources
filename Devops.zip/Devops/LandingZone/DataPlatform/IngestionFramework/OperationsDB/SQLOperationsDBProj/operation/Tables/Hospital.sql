﻿CREATE TABLE [operation].[Hospital] (
    [HospitalID]   INT           IDENTITY (1, 1) NOT NULL,
    [HospitalName] VARCHAR (100) NULL,
    [Country]      VARCHAR (100) NULL,
    [Active]       BIT           NULL,
    [ModifiedBy]   VARCHAR (500) NULL,
    [ModifiedOn]   DATETIME      NULL,
    CONSTRAINT [PK_HospitalName_HospitalID] PRIMARY KEY CLUSTERED ([HospitalID] ASC)
);









