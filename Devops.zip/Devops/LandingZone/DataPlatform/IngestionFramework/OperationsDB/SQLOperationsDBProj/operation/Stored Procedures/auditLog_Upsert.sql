﻿----------------------------------------------------------------------------------------------------------------------------
-- Procedure Name: [operation].[auditLog_Upsert] 
-- Purpose       : This procedure will accept all the parameters and will log the entry into the auditLog table
-- Created By    : Microsoft
 -- Creation Date : 12-Jul-2022
--  Version            Date            Modified By              Description
-------        -----------        ---------------          ---------------

  --   1.0           12-Jul-2022       Microsoft               Initial Version
  --- commenting for CICD Testing
  ----------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [operation].[auditLog_Upsert]
	(
	@InsertUpsert [smallint],
	@AuditLogID [int] NULL,
	@BatchScheduleID [smallint] NULL,
	@BatchProcessStatusNameID [smallint] NULL,
	@TableGroupNumber [smallint] NULL,
	
	@DataRead [decimal](19,4) NULL,
	@DataWritten [decimal](19,4) NULL,
	@Throughput [decimal](19,4) NULL,
	@RowsWritten [int] NULL,
	@MetadataControlID int ,
	@FilesorrowsWrite Int NULL,
	@FilesorrowsRead int NULL,
	@Errormessage varchar(max) NULL,
	@pipelineRunId Varchar(200) NULL,
	@pipelineName Varchar(100) NULL,
	@triggerId Varchar(100) NULL,
	@TriggerName Varchar(100) NULL,
	@triggerType Varchar(100) NULL,
	@AuditLogIDOutPut [int] NULL OUTPUT
	)

AS

/*
--Execution execution example:
@InsertUpsert: 1 Insert, 2 Upsert for a group of tables, 3 Upsert for a specific table, 4 End of Batch

--Example of stored procedure execution for @InsertUpsert = 1
EXECUTE [operation].[BatchProcess_Upsert] 2, 2, 22, 1, 1, 20, 24, 'dimproduct', NULL, NULL, NULL, NULL, NULL

*/

IF @InsertUpsert = 1
BEGIN
	--Create the AuditLogID
	BEGIN TRANSACTION;
		INSERT INTO
			[operation].Auditlog
			(

			[BatchProcessStatusNameID],
			[BatchScheduleID],
			[StartTime],
			[EndTime],
			[DurationInSeconds],
			IsSucceed,
			[pipelineRunId],
		    [pipelineName],
		    [TriggerId],
            [TriggerName],
            [TriggerType]
			)
		VALUES
			(
			
			0, --Status 0 = Waiting to process
			@BatchScheduleID,
			GETDATE(),
			NULL,
			NULL,
			1,
			@pipelineRunId,
		    @pipelineName,
		    @TriggerId,
            @TriggerName,
            @TriggerType
			)
	COMMIT;

	--Get last @AuditLogID
	DECLARE @AuditLogIDInserted INT
	SELECT @AuditLogIDInserted = SCOPE_IDENTITY();

    SET @AuditLogIDOutPut = @AuditLogIDInserted
    SELECT @AuditLogIDOutPut AS AuditLogIDOutPut

	--END - Get last @AuditLogID

		--Call table structure stored procedure
		EXECUTE [operation].[AuditLogDetails_Upsert]
			@InsertUpsert = 1,
			@AuditLogID = @AuditLogIDInserted,
			@MetadataControlID=@MetadataControlID,
		
			@BatchProcessStatusNameID = @BatchProcessStatusNameID,
            @DataRead = @DataRead,
			@DataWritten = @DataWritten,
			@Throughput = @Throughput,
			@RowsWritten = @RowsWritten,
			@BatchScheduleID=@BatchScheduleID,

			@FilesorrowsRead=@FilesorrowsRead,
			@FilesorrowsWrite =@FilesorrowsWrite,
	      
	       @Errormessage =@Errormessage,
		   @PipelineRunId=@PipelineRunId
		
		--END - Call table structure stored procedure

	--END - Create the AuditLogID
END

IF @InsertUpsert = 2
BEGIN
	--UPDATE process table (for a specific table)
	BEGIN TRANSACTION;
		UPDATE
			[operation].Auditlog
		SET

			[BatchProcessStatusNameID] = @BatchProcessStatusNameID,
			[EndTime] = GETDATE(),
			[DurationInSeconds] = DATEDIFF(SS,[StartTime],GETDATE())
		WHERE
			AuditLogID = @AuditLogID

		update al
		SET al.IsSucceed=0 ,al.BatchProcessStatusNameID=20
		FROM operation.AuditLog al
		JOIN operation.AuditLogDetails ald
		ON al.AuditLogID=ald.AuditLogID
		where al.AuditLogID=@AuditLogID and ald.AuditLogID=@AuditLogID
		and exists (select 1 from operation.AuditLogDetails where AuditLogID=
		@AuditLogID and IsSucceed=0 and BatchProcessStatusNameID=20)

	COMMIT;

		--Call table structure stored procedure (for a specific group of tables)
		EXECUTE [operation].[AuditLogDetails_Upsert]
			@InsertUpsert = 2,
			@AuditLogID = @AuditLogID,
			@MetadataControlID = @MetadataControlID,
	
			@BatchProcessStatusNameID = @BatchProcessStatusNameID,
			@DataRead = @DataRead,
			@DataWritten = @DataWritten,
			@Throughput = @Throughput,
			@RowsWritten = @RowsWritten,
			@BatchScheduleID=@BatchScheduleID,

		    @FilesorrowsRead=@FilesorrowsRead,
			@FilesorrowsWrite =@FilesorrowsWrite,
	      
	       @Errormessage =@Errormessage,
		   
		   @PipelineRunId=@PipelineRunId
			
		--END - Call table structure stored procedure (for a specific group of tables)

	--END - UPDATE process table (for a specific table)
END

IF @InsertUpsert = 3
BEGIN
	--Update the AuditLogID - END OF PROCESS
	BEGIN TRANSACTION;
		UPDATE
			[operation].AuditLog
		SET
			
			[BatchProcessStatusNameID] = @BatchProcessStatusNameID,
			[EndTime] = GETDATE(),
			[DurationInSeconds] = DATEDIFF(SS,[StartTime],GETDATE()),
			IsSucceed = 1
		WHERE
			AuditLogID = @AuditLogID

update al
		SET al.IsSucceed=0 ,al.BatchProcessStatusNameID=20
		FROM operation.AuditLog al
		JOIN operation.AuditLogDetails ald
		ON al.AuditLogID=ald.AuditLogID
		where al.AuditLogID=@AuditLogID and ald.AuditLogID=@AuditLogID
		and exists (select 1 from operation.AuditLogDetails where AuditLogID=
		@AuditLogID and IsSucceed=0 and BatchProcessStatusNameID=20)

	COMMIT;	
	--END - Update the AuditLogID - END OF PROCESS
END